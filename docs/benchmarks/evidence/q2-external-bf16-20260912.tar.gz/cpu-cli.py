import sys
import torch

def forbidden(*args, **kwargs):
    raise AssertionError("CUDA device access forbidden in CPU probe/report")

for name in ("is_available", "device_count", "current_device", "init", "_lazy_init"):
    setattr(torch.cuda, name, forbidden)

from vllm_lt.benchmarks.q2_external import main
raise SystemExit(main())
