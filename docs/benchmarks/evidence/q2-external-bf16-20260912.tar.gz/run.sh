#!/usr/bin/env bash
set -euo pipefail
cd /home/hsliu2/tmp/vllm-lt-q2-external
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH=/home/hsliu2/tmp/vllm-lt-q2-external
export HF_HUB_OFFLINE=1
export HF_MODULES_CACHE=/tmp/hsliu2-q2-bf16-hf-modules
export TRITON_CACHE_DIR=/tmp/hsliu2-q2-bf16-triton
numactl --all --physcpubind=12 --membind=0 \
  /tmp/hsliu2-venvs/vllm-lt-gsm8k/bin/python -m vllm_lt.benchmarks.q2_external run \
  --plan /tmp/hsliu2-q2-bf16-20260912/plan/plan.json \
  --output /tmp/hsliu2-q2-bf16-20260912/run
