# Q2 external BF16 W1 comparison

Evidence: **complete**; decision: **passed**.

BF16 fixed-four cached W1 latency spot check; token agreement is diagnostic, not an accuracy gate; no repeatability, quality or adaptive claim

Valid acknowledged executions: 4/4; measured: 2/2.

Canonical plan: `e3c004d823490e6c86f42b69d2eb0a3b7845c1a55993fb1903ff2f65d52841ee`.

| Pair | Native tokens/s | Official tokens/s | Native / official |
| --- | ---: | ---: | ---: |
| pair-1 | 16.830252 | 14.758655 | 1.140365 |

Delivery throughput uses the last actual token return. Final synchronized throughput, TTFT, TPOT, raw intervals, memory and setup are separate JSON fields.

